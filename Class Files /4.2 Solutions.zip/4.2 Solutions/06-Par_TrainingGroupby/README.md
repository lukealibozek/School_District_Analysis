# Training Grounds

## Instructions

* Using the DataFrame provided, do the following:

    * Convert the "Membership (Days)" column into weeks and then add this new series into the DataFrame

    * Create a Dataframe that has only the "Trainer", "Weight", and membership in days and weeks.

    * Using groupby get the average weight and length membership of the gym members for each trainer.

---

© 2021 Trilogy Education Services, LLC, a 2U, Inc. brand.  Confidential and Proprietary.  All Rights Reserved.